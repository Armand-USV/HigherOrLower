package course.higherorlower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int randomNumber, nrAttempts;
    TextView nrAttemptsEditText;
    Button verifyButton;

    public void OnVerifyButtonClick(View view) {

        EditText numberEditText = findViewById(R.id.editTextNumberDecimal);
        nrAttemptsEditText = findViewById(R.id.tvNrAttemps);
        nrAttempts = Integer.parseInt(nrAttemptsEditText.getText().toString());
        int numberEditTextInt = Integer.parseInt(numberEditText.getText().toString());
        String numberEditTextString = numberEditText.getText().toString();

        verifyButton = findViewById(R.id.btnVerify);

//        if (TextUtils.isEmpty(numberEditTextString)) {
//            Toast.makeText(this, "Please introduce a number !", Toast.LENGTH_LONG).show();
//        } else {
            if (numberEditTextInt == randomNumber) {
                Toast.makeText(this, "You find it ! Congrats! If you want to play again , press RESET button !", Toast.LENGTH_LONG).show();
                verifyButton.setEnabled(false);
                numberEditText.setFocusable(false);
            } else {
                if (numberEditTextInt > randomNumber) {
                    Toast.makeText(this, "Lower", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Higher", Toast.LENGTH_LONG).show();
                }
                nrAttempts--;
                nrAttemptsEditText.setText(String.valueOf(nrAttempts));
            }
            if (nrAttempts == 0) {
                Toast.makeText(this, "Your attempts have been wasted ! Please RESET your game !", Toast.LENGTH_LONG).show();
                verifyButton.setEnabled(false);
                numberEditText.setFocusable(false);
            }
        }
//    }

    public void OnResetButtonClick(View view) {

        EditText numberEditText = findViewById(R.id.editTextNumberDecimal);

        numberEditText.setText("");

        RandomNumber();

        numberEditText.setFocusableInTouchMode(true);
        verifyButton.setEnabled(true);

        nrAttemptsEditText.setText("5");

        Toast.makeText(this, "The number has been changed ! ", Toast.LENGTH_LONG).show();
    }

    public void RandomNumber() {
        Random random = new Random();
        randomNumber = random.nextInt(10) + 1;
        Log.i("--------------NUMBER : ", Integer.toString(randomNumber));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RandomNumber();
    }
}